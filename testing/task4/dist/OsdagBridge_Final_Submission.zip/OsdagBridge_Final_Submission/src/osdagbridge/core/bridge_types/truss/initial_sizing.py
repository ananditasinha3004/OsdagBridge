"""truss initial sizing (stub)."""
