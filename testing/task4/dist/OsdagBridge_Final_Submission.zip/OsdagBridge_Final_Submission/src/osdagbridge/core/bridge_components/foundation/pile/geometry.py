"""Pile geometry stub."""
